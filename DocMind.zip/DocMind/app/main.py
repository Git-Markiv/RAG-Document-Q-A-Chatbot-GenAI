"""DocMind - RAG Document Q&A. Run:  python run.py"""
from __future__ import annotations

import json
import re
import shutil
import threading
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass

from . import llm, rag
from .loaders import SUPPORTED

ROOT = Path(__file__).resolve().parent.parent
FOLDERS = {"demo": ROOT / "data" / "demo", "custom": ROOT / "data" / "uploads"}
for p in FOLDERS.values():
    p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="DocMind")
_indexes: dict[str, rag.Index] = {}
_lock = threading.Lock()


def get_index(ds: str) -> rag.Index:
    if ds not in FOLDERS:
        raise HTTPException(404, "Unknown dataset")
    with _lock:
        if ds not in _indexes:
            _indexes[ds] = rag.build_index(FOLDERS[ds])
        return _indexes[ds]


def reindex(ds: str) -> rag.Index:
    with _lock:
        _indexes[ds] = rag.build_index(FOLDERS[ds])
        return _indexes[ds]


def _safe_name(name: str) -> str:
    name = Path(name).name
    return re.sub(r"[^A-Za-z0-9._ \-()]", "_", name)[:120] or "file"


class AskBody(BaseModel):
    question: str
    dataset: str = "demo"
    doc: str | None = None
    k: int = 4
    history: list[dict] = []


@app.get("/api/status")
def status():
    out = {"provider": llm.provider(), "dense": rag._ST_AVAILABLE, "datasets": {}}
    for ds in FOLDERS:
        idx = get_index(ds)
        out["datasets"][ds] = {
            "docs": [{"name": n, "chunks": c} for n, c in idx.docs.items()],
            "chunks": len(idx.chunks),
        }
    return out


@app.post("/api/upload")
async def upload(files: list[UploadFile] = File(...)):
    saved, rejected = [], []
    for f in files:
        name = _safe_name(f.filename or "file")
        if Path(name).suffix.lower() not in SUPPORTED:
            rejected.append(name)
            continue
        dest = FOLDERS["custom"] / name
        with dest.open("wb") as out:
            shutil.copyfileobj(f.file, out)
        saved.append(name)
    idx = reindex("custom")
    return {"saved": saved, "rejected": rejected, "docs": [{"name": n, "chunks": c} for n, c in idx.docs.items()]}


@app.delete("/api/docs/{name}")
def delete_doc(name: str):
    p = FOLDERS["custom"] / _safe_name(name)
    if p.exists():
        p.unlink()
    reindex("custom")
    return {"ok": True}


@app.delete("/api/docs")
def clear_docs():
    for p in FOLDERS["custom"].glob("*"):
        if p.is_file() and not p.name.startswith("."):
            p.unlink()
    reindex("custom")
    return {"ok": True}


@app.post("/api/ask")
def ask(body: AskBody):
    q = body.question.strip()
    if not q:
        raise HTTPException(400, "Empty question")
    idx = get_index(body.dataset)
    sources = rag.search(idx, q, k=max(1, min(body.k, 8)), doc_filter=body.doc)

    def gen():
        yield json.dumps({"type": "sources", "sources": sources}) + "\n"
        for tok in llm.stream_answer(q, sources, body.history):
            yield json.dumps({"type": "token", "text": tok}) + "\n"
        yield json.dumps({"type": "done"}) + "\n"

    return StreamingResponse(gen(), media_type="application/x-ndjson")


app.mount("/static", StaticFiles(directory=ROOT / "app" / "static"), name="static")


@app.get("/")
def index():
    return FileResponse(ROOT / "app" / "static" / "index.html")
