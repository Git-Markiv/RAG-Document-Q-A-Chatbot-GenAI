"""Chunking + retrieval engine.

Retrieval is hybrid by default:
  * TF-IDF (word 1-2 grams)         -> works offline, zero downloads
  * Optional dense embeddings       -> if `sentence-transformers` is installed
Scores are fused with a weighted sum, then de-duplicated with MMR-style filtering.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from .loaders import SUPPORTED, load_file

try:  # optional dense retrieval
    from sentence_transformers import SentenceTransformer

    _ST_AVAILABLE = True
except Exception:  # pragma: no cover
    _ST_AVAILABLE = False

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(\[])")


@dataclass
class Chunk:
    id: int
    doc: str
    loc: str
    text: str
    heading: str = ""


@dataclass
class Index:
    chunks: list[Chunk] = field(default_factory=list)
    docs: dict[str, int] = field(default_factory=dict)  # doc name -> chunk count
    vec: TfidfVectorizer | None = None
    matrix: object = None
    dense: np.ndarray | None = None


_embedder = None


def _get_embedder():
    global _embedder
    if _embedder is None and _ST_AVAILABLE:
        _embedder = SentenceTransformer("all-MiniLM-L6-v2")
    return _embedder


# ---------------------------------------------------------------- chunking
def chunk_text(text: str, max_chars: int = 700, overlap_sents: int = 1) -> list[tuple[str, str]]:
    """Split text into (heading, chunk) pairs on sentence boundaries, tracking markdown headings."""
    out: list[tuple[str, str]] = []
    heading = ""
    for block in re.split(r"\n\s*\n", text.strip()):
        block = block.strip()
        if not block:
            continue
        m = re.match(r"^#{1,6}\s+(.*)", block)
        if m:
            heading = m.group(1).strip()
            block = block[m.end():].strip()
            if not block:
                continue
        sents = [s.strip() for s in _SENT_SPLIT.split(re.sub(r"\s+", " ", block)) if s.strip()]
        buf: list[str] = []
        size = 0
        for s in sents:
            if size + len(s) > max_chars and buf:
                out.append((heading, " ".join(buf)))
                buf = buf[-overlap_sents:] if overlap_sents else []
                size = sum(len(x) for x in buf)
            buf.append(s)
            size += len(s)
        if buf:
            out.append((heading, " ".join(buf)))
    return out


# ---------------------------------------------------------------- indexing
def build_index(folder: Path, use_dense: bool = True) -> Index:
    idx = Index()
    files = sorted(p for p in folder.glob("*") if p.suffix.lower() in SUPPORTED and p.is_file())
    for f in files:
        try:
            segments = load_file(f)
        except Exception as e:  # keep going if a single file is broken
            print(f"[warn] could not read {f.name}: {e}")
            continue
        n = 0
        for loc, text in segments:
            for heading, piece in chunk_text(text):
                if len(piece) < 25:
                    continue
                idx.chunks.append(Chunk(len(idx.chunks), f.name, loc, piece, heading))
                n += 1
        if n:
            idx.docs[f.name] = n
    if not idx.chunks:
        return idx

    corpus = [f"{c.heading}. {c.text}" if c.heading else c.text for c in idx.chunks]
    idx.vec = TfidfVectorizer(
        ngram_range=(1, 2), sublinear_tf=True, stop_words="english", min_df=1, strip_accents="unicode"
    )
    idx.matrix = idx.vec.fit_transform(corpus)
    if use_dense and _ST_AVAILABLE:
        try:
            idx.dense = _get_embedder().encode(corpus, normalize_embeddings=True, show_progress_bar=False)
        except Exception as e:  # pragma: no cover
            print(f"[warn] dense embeddings disabled: {e}")
    return idx


# ---------------------------------------------------------------- retrieval
def search(idx: Index, query: str, k: int = 4, doc_filter: str | None = None) -> list[dict]:
    if not idx.chunks or idx.vec is None:
        return []
    q = idx.vec.transform([query])
    sparse = (idx.matrix @ q.T).toarray().ravel()
    scores = sparse.copy()
    if idx.dense is not None:
        qd = _get_embedder().encode([query], normalize_embeddings=True)[0]
        dense = idx.dense @ qd
        scores = 0.45 * sparse / (sparse.max() or 1) + 0.55 * np.clip(dense, 0, None) / (dense.max() or 1)
    if doc_filter:
        mask = np.array([c.doc == doc_filter for c in idx.chunks])
        scores = np.where(mask, scores, 0)

    order = np.argsort(-scores)
    picked: list[int] = []
    for i in order:
        if scores[i] <= 0:
            break
        # skip near-duplicate neighbours of already-picked chunks
        if any(idx.chunks[i].doc == idx.chunks[j].doc and abs(i - j) == 1 and scores[i] < 0.6 * scores[j] for j in picked):
            continue
        if picked and scores[i] < 0.2 * scores[picked[0]]:
            break  # drop weakly related passages
        picked.append(int(i))
        if len(picked) >= k:
            break

    top = scores[picked[0]] if picked else 1
    results = []
    for rank, i in enumerate(picked, start=1):
        c = idx.chunks[i]
        results.append(
            {
                "n": rank,
                "doc": c.doc,
                "loc": c.loc,
                "heading": c.heading,
                "text": c.text,
                "score": round(float(scores[i] / (top or 1)), 3),
                "raw": round(float(scores[i]), 4),
            }
        )
    return results


# ---------------------------------------------------------------- extractive fallback answer
_WORD = re.compile(r"[a-z0-9]+")
_STOP = set(
    "a an the is are was were be been of in on at to for from by with and or but not what which who whom how why when where "
    "does do did can could should would about this that these those it its as into than then there their they you your i we our "
    "tell me explain describe give".split()
)


def extractive_answer(query: str, sources: list[dict], max_sents: int = 4) -> str:
    """Pick the most query-relevant sentences from retrieved chunks and cite them."""
    qw = {w for w in _WORD.findall(query.lower()) if w not in _STOP}
    cands = []
    for s in sources:
        for sent in _SENT_SPLIT.split(s["text"]):
            sent = sent.strip()
            if len(sent) < 30:
                continue
            sw = set(_WORD.findall(sent.lower()))
            overlap = len(qw & sw) / (len(qw) or 1)
            cands.append((overlap + 0.25 * s["score"], s["n"], sent, overlap))
    cands.sort(key=lambda x: -x[0])
    best = cands[0][3] if cands else 0
    relevant = [c for c in cands if c[3] > 0 and c[3] >= 0.5 * best]
    cands = relevant or cands[:1]
    chosen = sorted(cands[:max_sents], key=lambda x: (x[1], 0))
    if not chosen:
        return ""
    lines = [f"{sent} [{n}]" for _, n, sent, _o in chosen]
    return "\n\n".join(lines)
