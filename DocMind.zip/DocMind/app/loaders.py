"""Read documents (PDF, DOCX, TXT, MD, CSV) into a list of (location, text) segments."""
from __future__ import annotations

import csv
from pathlib import Path

SUPPORTED = {".pdf", ".docx", ".txt", ".md", ".csv"}


def load_file(path: Path) -> list[tuple[str, str]]:
    """Return [(location_label, text), ...] e.g. [("p. 3", "...")]."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        return _load_pdf(path)
    if ext == ".docx":
        return _load_docx(path)
    if ext == ".csv":
        return _load_csv(path)
    if ext in {".txt", ".md"}:
        text = path.read_text(encoding="utf-8", errors="ignore")
        return [("", text)]
    raise ValueError(f"Unsupported file type: {ext}")


def _load_pdf(path: Path):
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    out = []
    for i, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if text:
            out.append((f"p. {i}", text))
    return out


def _load_docx(path: Path):
    import docx

    d = docx.Document(str(path))
    parts = [p.text for p in d.paragraphs if p.text.strip()]
    for t in d.tables:
        for row in t.rows:
            parts.append(" | ".join(c.text.strip() for c in row.cells))
    return [("", "\n".join(parts))]


def _load_csv(path: Path):
    out = []
    with path.open(newline="", encoding="utf-8", errors="ignore") as f:
        rows = list(csv.reader(f))
    if not rows:
        return out
    header, body = rows[0], rows[1:]
    # group 20 rows per segment so each chunk keeps column names
    for i in range(0, len(body), 20):
        lines = []
        for r in body[i : i + 20]:
            lines.append("; ".join(f"{h}: {v}" for h, v in zip(header, r)))
        out.append((f"rows {i + 1}-{i + len(lines)}", "\n\n".join(lines)))
    return out
