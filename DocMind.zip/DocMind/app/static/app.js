/* DocMind frontend — vanilla JS, no build step. */
const $ = (s, r = document) => r.querySelector(s);
const WELCOME = document.querySelector("#welcome").cloneNode(true);
const state = { ds: "demo", scope: null, busy: false, history: [], status: null };

const SUGGESTIONS = {
  demo: [
    "What is the difference between precision and recall?",
    "How does non-maximum suppression work?",
    "Which YOLOv8 model should I use on a CPU?",
    "What chunk size works best for RAG?",
    "What is the AWS shared responsibility model?",
  ],
  custom: [],
};

/* ---------- helpers ---------- */
const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ext = (n) => (n.split(".").pop() || "").toLowerCase();

function toast(msg, kind = "") {
  const t = document.createElement("div");
  t.className = `toast ${kind}`;
  t.textContent = msg;
  $("#toasts").append(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 350); }, 3600);
}

function renderMarkdown(raw, nSources) {
  let html = esc(raw);
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/(?<![*\w])_([^_\n]+)_(?!\w)/g, "<em>$1</em>");
  // citations [1] or [1, 2]
  html = html.replace(/\[(\d+(?:\s*,\s*\d+)*)\]/g, (m, g) =>
    g.split(",").map((n) => {
      n = n.trim();
      return +n <= nSources ? `<button type="button" class="cite" data-n="${n}">${n}</button>` : "";
    }).join(""));
  const blocks = html.split(/\n{2,}/).map((b) => {
    const lines = b.split("\n");
    if (lines.every((l) => /^\s*([-*•]|\d+\.)\s+/.test(l))) {
      return "<ul>" + lines.map((l) => `<li>${l.replace(/^\s*([-*•]|\d+\.)\s+/, "")}</li>`).join("") + "</ul>";
    }
    return `<p>${lines.join("<br>")}</p>`;
  });
  return blocks.join("");
}

function highlight(text, query) {
  const words = [...new Set(query.toLowerCase().match(/[a-z0-9]{4,}/g) || [])];
  let out = esc(text);
  if (words.length) out = out.replace(new RegExp(`\\b(${words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})\\w*`, "gi"), "<mark>$&</mark>");
  return out;
}

/* ---------- status + datasets ---------- */
async function loadStatus() {
  const res = await fetch("/api/status");
  state.status = await res.json();
  const llm = state.status.provider !== "offline";
  $("#providerPill").classList.toggle("llm", llm);
  $("#providerText").textContent = llm
    ? `${state.status.provider === "anthropic" ? "Claude" : "OpenAI"} generation`
    : `Offline mode${state.status.dense ? " · hybrid" : ""}`;
  $("#providerPill").title = llm ? "Answers are written by an LLM from retrieved passages" : "No API key found: answers are extracted from your documents. Add a key in .env for LLM answers.";
  renderDocs();
}

function renderDocs() {
  const d = state.status.datasets[state.ds];
  const list = $("#docList");
  list.innerHTML = "";
  $("#docCount").textContent = d.docs.length;
  $("#clearBtn").hidden = !(state.ds === "custom" && d.docs.length);
  $("#uploadPanel").hidden = state.ds !== "custom";
  $("#dsName").textContent = state.ds === "demo" ? "Demo dataset" : "My documents";
  $("#dsMeta").textContent = `${plural(d.docs.length, "file")} · ${plural(d.chunks, "passage")}`;
  if (!d.docs.length) {
    list.innerHTML = `<li class="empty">${state.ds === "custom" ? "No documents yet.<br>Upload files below to start asking questions." : "Demo files missing."}</li>`;
  }
  d.docs.forEach((doc, i) => {
    const li = document.createElement("li");
    li.className = "doc" + (state.scope === doc.name ? " scoped" : "");
    li.style.animationDelay = `${i * 45}ms`;
    li.title = "Click to limit questions to this file";
    li.innerHTML = `<span class="ext ${esc(ext(doc.name))}">${esc(ext(doc.name).toUpperCase())}</span>
      <div class="doc-info"><div class="doc-name">${esc(doc.name)}</div><div class="doc-meta">${plural(doc.chunks, "passage")}</div></div>
      ${state.ds === "custom" ? '<button class="doc-x" title="Remove" aria-label="Remove">✕</button>' : ""}`;
    li.addEventListener("click", (e) => {
      if (e.target.closest(".doc-x")) return removeDoc(doc.name);
      setScope(state.scope === doc.name ? null : doc.name);
    });
    list.append(li);
  });
  renderChips();
}

function setScope(name) {
  state.scope = name;
  $("#scope").hidden = !name;
  if (name) $("#scopeName").textContent = name;
  document.querySelectorAll(".doc").forEach((el) => el.classList.toggle("scoped", el.querySelector(".doc-name")?.textContent === name));
}

function renderChips() {
  const box = $("#chips");
  box.innerHTML = "";
  const d = state.status.datasets[state.ds];
  $("#welcomeSub").textContent = state.ds === "custom" && !d.docs.length
    ? "Upload a PDF, Word, text, Markdown or CSV file to get started. Everything stays on your machine."
    : "Answers are grounded in your documents, with citations you can verify.";
  (d.docs.length ? SUGGESTIONS[state.ds] : []).forEach((q, i) => {
    const b = document.createElement("button");
    b.className = "chip"; b.textContent = q; b.style.animationDelay = `${0.35 + i * 80}ms`;
    b.onclick = () => ask(q);
    box.append(b);
  });
}

function switchDataset(ds) {
  if (ds === state.ds) return;
  state.ds = ds; state.scope = null; setScope(null);
  $("#segThumb").parentElement.dataset.active = ds;
  document.querySelectorAll(".seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.ds === ds));
  resetChat();
  renderDocs();
  closeSidebar();
}

/* ---------- upload ---------- */
function upload(files) {
  if (!files.length) return;
  const fd = new FormData();
  [...files].forEach((f) => fd.append("files", f));
  const bar = $("#progress");
  bar.classList.add("on");
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "/api/upload");
  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) {
      bar.classList.remove("indeterminate");
      bar.firstElementChild.style.width = `${(e.loaded / e.total) * 100}%`;
      if (e.loaded === e.total) bar.classList.add("indeterminate"); // server is indexing
    }
  };
  xhr.onload = async () => {
    bar.classList.remove("on", "indeterminate"); bar.firstElementChild.style.width = "0";
    if (xhr.status !== 200) return toast("Upload failed", "err");
    const r = JSON.parse(xhr.responseText);
    if (r.saved.length) toast(`Indexed ${r.saved.length} file${r.saved.length > 1 ? "s" : ""} ✓`, "ok");
    if (r.rejected.length) toast(`Unsupported: ${r.rejected.join(", ")}`, "err");
    await loadStatus();
    if (r.saved.length) resetChat();
  };
  xhr.onerror = () => { bar.classList.remove("on"); toast("Upload failed", "err"); };
  xhr.send(fd);
}

async function removeDoc(name) {
  await fetch(`/api/docs/${encodeURIComponent(name)}`, { method: "DELETE" });
  if (state.scope === name) setScope(null);
  await loadStatus();
}

/* ---------- chat ---------- */
function resetChat() {
  state.history = [];
  const chat = $("#chat");
  chat.innerHTML = "";
  chat.append(WELCOME.cloneNode(true));
  renderChips();
}
function inner() {
  let el = $(".chat-inner");
  if (!el) {
    $("#welcome")?.remove();
    el = document.createElement("div");
    el.className = "chat-inner";
    $("#chat").innerHTML = "";
    $("#chat").append(el);
  }
  return el;
}
const scrollDown = () => { const c = $("#chat"); c.scrollTo({ top: c.scrollHeight, behavior: "smooth" }); };

async function ask(question) {
  question = question.trim();
  if (!question || state.busy) return;
  state.busy = true; $("#send").disabled = true;
  $("#input").value = ""; autosize();

  const wrap = inner();
  const u = document.createElement("div");
  u.className = "msg user";
  u.innerHTML = `<div class="bubble-user">${esc(question)}</div>`;
  wrap.append(u);

  const a = document.createElement("div");
  a.className = "msg";
  a.innerHTML = `<div class="avatar"><svg viewBox="0 0 32 32"><path d="M9 11h14M9 16h14M9 21h8" stroke="#fff" stroke-width="2.6" stroke-linecap="round" fill="none"/></svg></div>
    <div class="assistant"><div class="answer"><span class="typing"><i></i><i></i><i></i></span></div><div class="src-wrap"></div></div>`;
  wrap.append(a);
  scrollDown();

  const ans = $(".answer", a), srcWrap = $(".src-wrap", a);
  srcWrap.innerHTML = `<div class="sources-title">Searching documents…</div><div class="sources"><div class="skeleton"></div><div class="skeleton"></div></div>`;

  let text = "", nSrc = 0, sources = [];
  try {
    const res = await fetch("/api/ask", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, dataset: state.ds, doc: state.scope, k: +$("#kRange").value, history: state.history }),
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || res.statusText);
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
        if (!line) continue;
        const ev = JSON.parse(line);
        if (ev.type === "sources") {
          sources = ev.sources; nSrc = sources.length;
          renderSources(srcWrap, sources, question);
        } else if (ev.type === "token") {
          text += ev.text;
          ans.classList.add("streaming");
          ans.innerHTML = renderMarkdown(text, nSrc);
          scrollDown();
        }
      }
    }
    ans.classList.remove("streaming");
    ans.innerHTML = renderMarkdown(text, nSrc) || "<p>No answer.</p>";
    state.history.push({ role: "user", content: question }, { role: "assistant", content: text });
  } catch (e) {
    ans.innerHTML = `<p>Something went wrong: ${esc(String(e.message || e))}</p>`;
    srcWrap.innerHTML = "";
  }
  state.busy = false; $("#send").disabled = !$("#input").value.trim();
  $("#input").focus();
}

function renderSources(host, sources, query) {
  if (!sources.length) { host.innerHTML = ""; return; }
  host.innerHTML = `<div class="sources-title">Sources</div><div class="sources"></div>`;
  const grid = $(".sources", host);
  sources.forEach((s, i) => {
    const el = document.createElement("div");
    el.className = "src"; el.id = `src-${host.dataset.id || ""}${s.n}`; el.dataset.n = s.n;
    el.style.animationDelay = `${i * 90}ms`;
    el.innerHTML = `<div class="src-head"><span class="src-n">${s.n}</span><span class="src-name" title="${esc(s.doc)}">${esc(s.doc)}</span><span class="src-loc">${esc(s.loc)}</span></div>
      ${s.heading ? `<div class="src-heading">${esc(s.heading)}</div>` : ""}
      <div class="src-text">${highlight(s.text, query)}</div>
      <div class="bar" title="Relevance ${Math.round(s.score * 100)}%"><i></i></div>`;
    el.addEventListener("click", () => el.classList.toggle("open"));
    grid.append(el);
    requestAnimationFrame(() => requestAnimationFrame(() => ($(".bar i", el).style.width = `${Math.max(8, s.score * 100)}%`)));
  });
}

// click on [n] citation -> flash the matching source card in the same message
document.addEventListener("click", (e) => {
  const c = e.target.closest(".cite");
  if (!c) return;
  const card = c.closest(".assistant").querySelector(`.src[data-n="${c.dataset.n}"]`);
  if (!card) return;
  card.scrollIntoView({ behavior: "smooth", block: "center" });
  card.classList.remove("flash"); void card.offsetWidth; card.classList.add("flash");
  card.classList.add("open");
});

/* ---------- composer ---------- */
function autosize() {
  const t = $("#input");
  t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 160) + "px";
  $("#send").disabled = state.busy || !t.value.trim();
}
$("#input").addEventListener("input", autosize);
$("#input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask($("#input").value); }
});
$("#composer").addEventListener("submit", (e) => { e.preventDefault(); ask($("#input").value); });

/* ---------- wiring ---------- */
document.querySelectorAll(".seg-btn").forEach((b) => b.addEventListener("click", () => switchDataset(b.dataset.ds)));
$("#newChat").onclick = resetChat;
$("#scopeClear").onclick = () => setScope(null);
$("#kRange").oninput = (e) => ($("#kVal").textContent = e.target.value);
$("#clearBtn").onclick = async () => {
  if (!confirm("Remove all uploaded documents?")) return;
  await fetch("/api/docs", { method: "DELETE" }); setScope(null); await loadStatus(); resetChat();
};

const drop = $("#drop"), fileInput = $("#fileInput");
drop.addEventListener("click", () => fileInput.click());
drop.addEventListener("keydown", (e) => (e.key === "Enter" || e.key === " ") && fileInput.click());
fileInput.addEventListener("change", () => { upload(fileInput.files); fileInput.value = ""; });
["dragenter", "dragover"].forEach((ev) => window.addEventListener(ev, (e) => { e.preventDefault(); if (state.ds === "custom") drop.classList.add("over"); }));
["dragleave", "drop"].forEach((ev) => window.addEventListener(ev, (e) => { e.preventDefault(); if (ev === "drop" || !e.relatedTarget) drop.classList.remove("over"); }));
window.addEventListener("drop", (e) => {
  if (state.ds !== "custom") { switchDataset("custom"); }
  upload(e.dataTransfer.files);
});

/* theme */
const savedTheme = (() => { try { return localStorage.getItem("dm-theme"); } catch { return null; } })();
if (savedTheme) document.documentElement.dataset.theme = savedTheme;
$("#themeBtn").onclick = () => {
  const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem("dm-theme", t); } catch {}
};

/* mobile sidebar */
const openSidebar = () => { $("#sidebar").classList.add("open"); $("#scrim").classList.add("on"); };
const closeSidebar = () => { $("#sidebar").classList.remove("open"); $("#scrim").classList.remove("on"); };
$("#openSidebar").onclick = openSidebar; $("#closeSidebar").onclick = closeSidebar; $("#scrim").onclick = closeSidebar;

loadStatus().then(() => { autosize(); $("#input").focus(); }).catch(() => toast("Cannot reach the server", "err"));
