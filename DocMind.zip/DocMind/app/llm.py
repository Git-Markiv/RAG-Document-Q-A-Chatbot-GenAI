"""Answer generation. Uses an LLM if an API key is configured, else an offline extractive answer.

Set one of these in `.env`:
    ANTHROPIC_API_KEY=...   (optional ANTHROPIC_MODEL, default claude-sonnet-4-5)
    OPENAI_API_KEY=...      (optional OPENAI_MODEL, default gpt-4o-mini)
"""
from __future__ import annotations

import os
import time
from typing import Iterator

from .rag import extractive_answer

SYSTEM = (
    "You are DocMind, a precise assistant that answers ONLY from the provided context passages. "
    "Cite the passages you use inline as [1], [2] matching their numbers. "
    "If the context does not contain the answer, say you could not find it in the documents. "
    "Be concise, use short paragraphs or bullet points, and never invent facts."
)


def provider() -> str:
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    return "offline"


def _context(sources: list[dict]) -> str:
    return "\n\n".join(f"[{s['n']}] ({s['doc']} {s['loc']}) {s['text']}" for s in sources)


def _messages(question: str, sources: list[dict], history: list[dict]):
    msgs = [m for m in history[-6:] if m.get("role") in ("user", "assistant")]
    msgs.append({"role": "user", "content": f"Context passages:\n{_context(sources)}\n\nQuestion: {question}"})
    return msgs


def stream_answer(question: str, sources: list[dict], history: list[dict]) -> Iterator[str]:
    if not sources:
        yield from _fake_stream("I couldn't find anything relevant to that in the selected documents. Try rephrasing, or add more documents.")
        return

    prov = provider()
    try:
        if prov == "anthropic":
            import anthropic

            client = anthropic.Anthropic()
            with client.messages.stream(
                model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5"),
                max_tokens=700,
                system=SYSTEM,
                messages=_messages(question, sources, history),
            ) as stream:
                for t in stream.text_stream:
                    yield t
            return
        if prov == "openai":
            from openai import OpenAI

            client = OpenAI()
            stream = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                stream=True,
                messages=[{"role": "system", "content": SYSTEM}] + _messages(question, sources, history),
            )
            for ev in stream:
                if ev.choices and ev.choices[0].delta.content:
                    yield ev.choices[0].delta.content
            return
    except Exception as e:  # fall back gracefully
        yield f"_(LLM unavailable: {type(e).__name__}. Showing an offline answer.)_\n\n"

    ans = extractive_answer(question, sources) or "I couldn't find a clear answer in the documents."
    yield from _fake_stream(ans)


def _fake_stream(text: str) -> Iterator[str]:
    """Word-by-word streaming so the offline mode feels as live as an LLM."""
    for w in text.split(" "):
        yield w + " "
        time.sleep(0.018)
