# YOLOv8 Practical Guide

## Overview
YOLO stands for "You Only Look Once". YOLOv8, released by Ultralytics in 2023, is a single-stage detector that predicts bounding boxes and class probabilities in one forward pass, which makes it very fast. It supports detection, segmentation, classification and pose estimation from the same API.

## Model sizes
YOLOv8 ships in five sizes: nano (n), small (s), medium (m), large (l) and extra-large (x). The nano model has about 3.2 million parameters and runs comfortably on a CPU, while the extra-large model has about 68 million parameters and needs a GPU for real-time speed. Choose the smallest model that meets your accuracy target, especially when deploying on CPU or edge devices.

## Preparing a dataset
YOLOv8 expects images and one text label file per image, where each line holds a class index and a normalised bounding box (x_center, y_center, width, height). Tools such as Roboflow make annotation, augmentation and export in YOLO format straightforward. A common split is 80 percent training, 10 percent validation and 10 percent test. Aim for at least 100 to 200 annotated instances per class, and more when classes look alike.

## Training
Training is started with a single call, for example model.train(data="data.yaml", epochs=50, imgsz=640). Useful hyperparameters are the number of epochs, image size, batch size and the learning rate. Watch the validation mAP and loss curves; if validation loss rises while training loss falls, the model is overfitting and you should add augmentation, collect more data or stop earlier.

## Inference and speed
At inference you can set the confidence threshold and the IoU threshold for NMS. Lower image sizes such as 416 are faster than 640 with a small accuracy cost. Exporting the model to ONNX or OpenVINO often speeds up CPU inference noticeably. A YOLOv8n model can reach tens of milliseconds per image on a modern laptop CPU.

## Common problems
If the model confuses similar classes, add more varied examples of each. If it misses small objects, train at a larger image size. If there are many false positives, increase the confidence threshold or add background images with no objects.
