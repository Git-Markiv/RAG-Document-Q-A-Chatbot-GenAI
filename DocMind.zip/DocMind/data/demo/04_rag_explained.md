# Retrieval-Augmented Generation (RAG)

## What is RAG?
Retrieval-Augmented Generation combines a search step with a language model. Instead of relying only on what the model memorised during training, the system first retrieves relevant passages from your own documents and then asks the model to answer using those passages. This reduces hallucinations, keeps answers up to date, and lets you cite sources.

## The RAG pipeline
A typical pipeline has five stages. First, documents are loaded and cleaned. Second, they are split into chunks. Third, each chunk is converted into a vector embedding or a sparse keyword representation and stored in an index. Fourth, at question time the query is embedded and the most similar chunks are retrieved. Fifth, the chunks and the question are placed into a prompt and the language model writes the final answer with citations.

## Chunking strategy
Chunk size is a trade-off. Small chunks of 200 to 500 characters are precise but may lose context, while large chunks keep context but dilute the relevant signal and cost more tokens. Splitting on sentence or paragraph boundaries and adding a small overlap between neighbouring chunks keeps ideas intact. Preserving headings as metadata helps both retrieval and citations.

## Embeddings and vector search
Embeddings map text to dense vectors so that texts with similar meaning are close together. Similarity is usually measured with cosine similarity. Popular open-source embedding models include all-MiniLM-L6-v2, and vector stores include FAISS, Chroma and pgvector. Approximate nearest neighbour search makes retrieval fast even for millions of chunks.

## Hybrid retrieval
Keyword methods such as TF-IDF and BM25 excel at exact terms like names, codes and acronyms, while dense embeddings capture paraphrases and meaning. Hybrid retrieval fuses both scores and typically beats either method alone. A reranker model can further reorder the top results for better precision.

## Evaluating a RAG system
Evaluate retrieval and generation separately. For retrieval, measure recall at k and mean reciprocal rank on a set of test questions with known source passages. For generation, check faithfulness, meaning that every claim is supported by the retrieved context, and answer relevance. Tools such as RAGAS automate many of these checks.

## Common failure modes
Typical problems are poor chunking, missing documents, a retriever that returns irrelevant passages, prompts that let the model ignore the context, and context windows overflowing with too many chunks. Instructing the model to say "I could not find this in the documents" when evidence is missing is a simple and effective safeguard.
