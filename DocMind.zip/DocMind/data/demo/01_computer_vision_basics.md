# Computer Vision Basics

## What is computer vision?
Computer vision is a field of artificial intelligence that enables machines to interpret and understand images and video. Typical tasks include image classification, object detection, semantic segmentation, and optical character recognition. Modern systems rely mostly on deep convolutional neural networks and, more recently, vision transformers.

## Image classification
Image classification assigns a single label to a whole image, such as "cat" or "defective". A classifier outputs a probability for every class, and the highest probability is the prediction. Common metrics are accuracy, precision, recall and the F1-score. Accuracy can be misleading on imbalanced datasets, so F1-score is often reported alongside it.

## Object detection
Object detection finds where objects are in an image and what they are. Each detection contains a bounding box, a class label and a confidence score. Detectors are evaluated with mean average precision (mAP), which averages precision across recall levels and classes. The notation mAP@0.5 means a prediction counts as correct when its Intersection over Union (IoU) with the ground truth is at least 0.5.

## Intersection over Union and NMS
IoU measures the overlap between a predicted box and a ground-truth box by dividing the area of their intersection by the area of their union. Non-maximum suppression (NMS) removes duplicate detections: it keeps the box with the highest confidence and discards other boxes whose IoU with it exceeds a threshold. Raising the confidence threshold gives fewer but more reliable detections, while lowering it increases recall at the cost of more false positives.

## Data augmentation
Augmentation artificially enlarges a training set by applying random flips, rotations, crops, brightness changes and noise. It reduces overfitting and helps models generalise to new lighting conditions and camera angles. For detection tasks the bounding boxes must be transformed together with the image.

## Transfer learning
Transfer learning starts from a network pre-trained on a large dataset such as ImageNet or COCO and fine-tunes it on a smaller custom dataset. It needs far less data and training time than training from scratch, which is why most practical projects use it.
