# Machine Learning Essentials

## Supervised learning
In supervised learning a model learns a mapping from inputs to known labels. Classification predicts categories and regression predicts continuous values. Data is usually split into training, validation and test sets so that performance is measured on examples the model has never seen.

## Random Forest
A Random Forest is an ensemble of many decision trees. Each tree is trained on a bootstrap sample of the data and considers only a random subset of features at every split. Predictions are combined by majority vote for classification or averaging for regression. This bagging approach reduces variance, handles non-linear relationships, needs little feature scaling, and provides feature importance scores. Its main drawbacks are larger model size and slower inference than a single tree.

## Overfitting and regularisation
Overfitting happens when a model memorises the training data and performs poorly on new data. Remedies include collecting more data, simplifying the model, early stopping, dropout, weight decay, cross-validation and data augmentation. Underfitting is the opposite problem, where the model is too simple to capture the pattern.

## Evaluation metrics
Precision is the fraction of positive predictions that are correct. Recall is the fraction of real positives that were found. The F1-score is the harmonic mean of precision and recall. A confusion matrix shows exactly which classes get mixed up. For imbalanced data, prefer F1, precision-recall curves or ROC-AUC over plain accuracy.

## Feature engineering
Good features often matter more than the choice of algorithm. Examples are scaling numeric values, encoding categories, extracting texture and edge features from images, creating ratios and aggregations, and removing highly correlated or uninformative columns.

## Gradient boosting
Gradient boosting builds trees sequentially, with each new tree correcting the errors of the previous ones. Libraries such as XGBoost and LightGBM are among the strongest methods for tabular data, but they need more careful tuning than Random Forests to avoid overfitting.
