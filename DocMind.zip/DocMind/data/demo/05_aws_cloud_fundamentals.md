# AWS Cloud Fundamentals

## What is cloud computing?
Cloud computing delivers computing resources such as servers, storage, databases and networking over the internet with pay-as-you-go pricing. Its main benefits are elasticity, global reach, lower upfront cost and faster experimentation. The three service models are Infrastructure as a Service (IaaS), Platform as a Service (PaaS) and Software as a Service (SaaS).

## Core AWS services
Amazon EC2 provides resizable virtual servers. Amazon S3 is object storage designed for 99.999999999 percent durability and is commonly used for datasets, backups and static websites. AWS Lambda runs code without managing servers and bills per execution. Amazon RDS offers managed relational databases, and DynamoDB is a managed NoSQL key-value database. Amazon SageMaker is a managed platform for building, training and deploying machine learning models.

## Regions and Availability Zones
An AWS Region is a geographic area containing multiple isolated Availability Zones, each made of one or more data centres. Deploying across several Availability Zones improves fault tolerance and availability. Choose a Region based on latency to users, data-residency rules, service availability and price.

## Shared responsibility model
AWS is responsible for security of the cloud, which covers the physical data centres, hardware and core services. The customer is responsible for security in the cloud, which covers data, identity and access management, operating-system patches on EC2, and network configuration. Identity and Access Management (IAM) should follow the principle of least privilege, and multi-factor authentication should be enabled on the root account.

## Pricing and cost control
EC2 can be paid for On-Demand, with Savings Plans or Reserved Instances for steady workloads, or with Spot Instances for interruptible work at large discounts. The AWS Free Tier lets new accounts try many services at no cost within limits. Budgets and Cost Explorer help track spending and set alerts.

## Deploying a machine learning API
A common pattern is to wrap a trained model in a FastAPI service, package it in a Docker container and run it on EC2, Elastic Beanstalk or AWS App Runner. Model files are kept in S3, logs go to CloudWatch, and an Application Load Balancer distributes traffic. For occasional requests, Lambda with a container image can be cheaper than an always-on server.
